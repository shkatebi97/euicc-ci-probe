@echo off
setlocal
if not exist "%~dp0gradle\wrapper\gradle-wrapper.jar" (
    echo Run py -3 tools\bootstrap_wrapper.py first.
    exit /b 1
)
if defined JAVA_HOME (
    "%JAVA_HOME%\bin\java.exe" -classpath "%~dp0gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
) else (
    java -classpath "%~dp0gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
)
