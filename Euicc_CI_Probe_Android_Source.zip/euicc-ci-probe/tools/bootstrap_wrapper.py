#!/usr/bin/env python3
"""Fetch the official Gradle 8.11.1 wrapper jar and pin official SHA-256 sums."""
import hashlib
from pathlib import Path
import re
import urllib.request

VERSION = "8.11.1"
ROOT = Path(__file__).resolve().parents[1]
WRAPPER = ROOT / "gradle" / "wrapper"


def fetch(url):
    request = urllib.request.Request(url, headers={"User-Agent": "EuiccCiProbe-bootstrap/1.0"})
    with urllib.request.urlopen(request, timeout=90) as response:
        return response.read()


def checksum(name):
    value = fetch(f"https://services.gradle.org/distributions/gradle-{VERSION}-{name}.sha256")
    digest = value.decode("ascii").strip()
    if not re.fullmatch(r"[0-9a-fA-F]{64}", digest):
        raise RuntimeError("Gradle returned an invalid checksum")
    return digest.lower()


def main():
    wrapper_sha = checksum("wrapper.jar")
    distribution_sha = checksum("bin.zip")
    url = f"https://raw.githubusercontent.com/gradle/gradle/v{VERSION}/gradle/wrapper/gradle-wrapper.jar"
    jar = fetch(url)
    if hashlib.sha256(jar).hexdigest() != wrapper_sha:
        raise RuntimeError("Gradle wrapper checksum mismatch; no jar was installed")
    WRAPPER.mkdir(parents=True, exist_ok=True)
    (WRAPPER / "gradle-wrapper.jar").write_bytes(jar)
    properties = WRAPPER / "gradle-wrapper.properties"
    text = properties.read_text(encoding="utf-8")
    text = re.sub(r"(?m)^distributionSha256Sum=.*\n?", "", text)
    properties.write_text(text.rstrip() + f"\ndistributionSha256Sum={distribution_sha}\n", encoding="utf-8")
    (ROOT / "gradlew").chmod((ROOT / "gradlew").stat().st_mode | 0o111)
    print("Verified Gradle wrapper installed. Open this folder in Android Studio.")
    print("Wrapper SHA-256:", wrapper_sha)
    print("Gradle distribution SHA-256:", distribution_sha)


if __name__ == "__main__":
    main()
