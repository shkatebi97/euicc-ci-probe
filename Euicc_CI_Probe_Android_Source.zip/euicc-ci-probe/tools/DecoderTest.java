package org.example.euiccciprobe;

import java.io.ByteArrayOutputStream;
import java.util.Arrays;

/** Dependency-free fixtures: correct ASN.1 tags, lengths, order and malformed data. */
public final class DecoderTest {
    private static int checks;
    private static byte[] tlv(String tag, byte[] value) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] tagBytes = EuiccInfoDecoder.unhex(tag);
        out.write(tagBytes, 0, tagBytes.length);
        int n = value.length;
        if (n < 128) out.write(n);
        else if (n < 256) { out.write(0x81); out.write(n); }
        else { out.write(0x82); out.write(n >>> 8); out.write(n); }
        out.write(value, 0, value.length); return out.toByteArray();
    }
    private static byte[] join(byte[]... parts) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        for (byte[] part : parts) out.write(part, 0, part.length);
        return out.toByteArray();
    }
    private static void check(boolean condition, String name) {
        if (!condition) throw new AssertionError(name); checks++;
    }
    private static void rejects(byte[] payload, int tag, String name) {
        try { EuiccInfoDecoder.decode(payload, tag); }
        catch (IllegalArgumentException expected) { checks++; return; }
        throw new AssertionError("Accepted invalid fixture: " + name);
    }
    public static void main(String[] args) {
        // These are synthetic CI identifiers, not data from a Samsung phone.
        byte[] first = new byte[20], second = new byte[20];
        Arrays.fill(first, (byte) 0x11); Arrays.fill(second, (byte) 0x22);
        byte[] version = tlv("82", new byte[]{2, 7, 0});
        byte[] verification = tlv("A9", join(tlv("04", first), tlv("04", second)));
        byte[] signing = tlv("AA", tlv("04", second));
        byte[] fields = join(version, verification, signing);
        byte[] info1 = tlv("BF20", fields);
        EuiccInfoDecoder.Info result = EuiccInfoDecoder.decode(info1, 0xbf20);
        check(result.svn.equals("2.7.0"), "SVN");
        check(result.verification.size() == 2, "verification count");
        check(result.signing.size() == 1, "signing count");
        check(result.verification.get(0).equals(EuiccInfoDecoder.hex(first)), "priority order");
        check(result.signing.get(0).equals(EuiccInfoDecoder.hex(second)), "distinct signing list");
        byte[] large = tlv("BF22", join(tlv("84", new byte[300]), fields));
        check(EuiccInfoDecoder.decode(large, 0xbf22).verification.size() == 2,
            "long lengths and skipping unknown fields");
        check(EuiccInfoDecoder.decode(tlv("BF20", join(version,
            tlv("A9", new byte[0]), tlv("AA", new byte[0]))), 0xbf20).signing.isEmpty(), "empty lists");
        rejects(Arrays.copyOf(info1, info1.length - 1), 0xbf20, "truncated root");
        rejects(join(info1, new byte[]{0}), 0xbf20, "trailing bytes");
        rejects(info1, 0xbf22, "wrong response tag");
        rejects(tlv("BF20", join(version, verification)), 0xbf20, "missing list");
        rejects(tlv("BF20", join(fields, verification)), 0xbf20, "duplicate list");
        rejects(EuiccInfoDecoder.unhex("BF20800000"), 0xbf20, "indefinite length");
        rejects(tlv("BF20", join(version, tlv("A9", tlv("05", first)), signing)),
            0xbf20, "wrong identifier tag");
        rejects(tlv("BF20", join(tlv("82", new byte[]{2,7}), verification, signing)),
            0xbf20, "wrong version length");
        rejects(tlv("BF20", join(fields, version)), 0xbf20, "duplicate version");
        System.out.println("Decoder checks passed: " + checks);
    }
}
