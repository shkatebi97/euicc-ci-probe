#!/bin/sh
set -eu
probe_project_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
probe_test_dir=$(mktemp -d)
trap 'rm -rf "$probe_test_dir"' EXIT
javac -d "$probe_test_dir" \
  "$probe_project_dir/app/src/main/java/org/example/euiccciprobe/EuiccInfoDecoder.java" \
  "$probe_project_dir/tools/DecoderTest.java"
java -cp "$probe_test_dir" org.example.euiccciprobe.DecoderTest
