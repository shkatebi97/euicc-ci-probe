# eUICC CI Probe — ordinary Android APK

This is a small Java app for testing whether your unrooted Samsung S23 FE exposes
its internal eUICC to an ordinary APK through Android's public Open Mobile API
(OMAPI). If access is allowed, it reads and decodes both CI public-key identifier
lists. If access is denied, it reports the actual failure.

**Installing an APK does not grant privileged LPA access. On a stock S23 FE, denial
or an unavailable eUICC reader is the expected outcome. This project cannot
guarantee extraction of the internal eUICC's CI list.** That expectation is an
inference from Android's access model, not a test on your particular firmware.

## What the app does

1. Shows phone/Android version, optional OMAPI/eUICC feature flags and public eUICC
   OS-version information where available.
2. Connects to `android.se.omapi.SEService` and lists readers.
3. Lets you select a `SIM*` reader. Reader labels depend on firmware; SIM2 is not
   guaranteed to be the internal eUICC.
4. Opens a logical channel to the Consumer ISD-R application:
   `A0000005591010FFFFFFFF8900000100`.
5. Sends only the following information requests if opening the channel succeeds:

   | Request | DER data | APDU before OMAPI adds channel bits |
   |---|---|---|
   | GetEUICCInfo1 | `BF2000` | `80 E2 91 00 03 BF 20 00 00` |
   | GetEUICCInfo2 | `BF2200` | `80 E2 91 00 03 BF 22 00 00` |

6. Decodes `euiccCiPKIdListForVerification` and `euiccCiPKIdListForSigning`, preserving
   their order. These are SKIs, not complete DER certificates. The signing list
   identifies the CI ancestry of the eUICC's credentials; the eUICC signs with its
   own private key.
7. Shows/copies/shares the report and saves the most recent completed report as
   `files/report.txt` in the app's private storage.

The manifest requests no runtime or privileged permissions and no network access.
The app does not change profiles, request a download, reset the eUICC or read private
keys. OMAPI handles logical-channel numbering and `61xx`/`6Cxx` response processing.
The project has no external app libraries, Kotlin, AndroidX or native code.

## Why this uses OMAPI instead of pySim/lpac

`EuiccCardManager.requestEuiccInfo1/2` belong to the Android system/LPA API. They are
not accessible to this ordinary APK. `TelephonyManager.iccOpenLogicalChannel` also
requires `MODIFY_PHONE_STATE` or carrier privileges. Declaring those permissions
does not grant them to a sideloaded app.

pySim and desktop lpac still need a usable APDU transport; they cannot create that
access through USB debugging. OMAPI is the public transport worth testing here,
but its secure-element access control can deny both the application selection and
individual APDUs. App signing-certificate hashes are included in the report to
identify the APK if an OEM/eUICC vendor investigates an allowlisting request.

## Build, step by step (Android Studio)

1. Install Android Studio from <https://developer.android.com/studio>. Complete its
   setup wizard. Install Python 3 if it is not already available.
2. Extract this ZIP into a writable folder. Keep `settings.gradle`, `app/`,
   `gradle/` and `tools/` together inside `euicc-ci-probe/`.
3. In a terminal, change into that directory and fetch the official wrapper jar:

   Linux/macOS:

   ```bash
   cd /your/path/euicc-ci-probe
   python3 tools/bootstrap_wrapper.py
   ```

   Windows PowerShell:

   ```powershell
   Set-Location C:\your\path\euicc-ci-probe
   py -3 tools\bootstrap_wrapper.py
   ```

   The script downloads the official Gradle 8.11.1 wrapper jar from the Gradle
   GitHub repository, verifies its official SHA-256 checksum, and pins the Gradle
   distribution's official checksum. It requires internet access to
   `raw.githubusercontent.com` and `services.gradle.org`. The wrapper jar is not
   included in this source-only ZIP.

4. In Android Studio, use **Open** and select the `euicc-ci-probe` directory. This
   is an existing project; you do not need to create a new Activity/template.
5. In **Tools → SDK Manager**, install:

   - Android SDK Platform 35 (Android 15).
   - Android SDK Build-Tools 35.0.0 (enable Show Package Details if necessary).
   - Android SDK Platform-Tools, which includes `adb`.

   The phone itself does not need to run Android 15. Minimum runtime API is 28.
6. In **Settings → Build, Execution, Deployment → Build Tools → Gradle**, choose a
   full JDK 17 for **Gradle JDK**. Use Android Studio's Download JDK option if
   necessary. This project pins AGP 8.9.2 and Gradle 8.11.1; no version upgrades are
   needed. Gradle must be allowed to fetch its dependencies from Google/Maven.
7. Run **Sync Project with Gradle Files**. If Android Studio asks to install missing
   SDK components, install them. It normally creates `local.properties` with your
   SDK path automatically.
8. Build the debug APK using the Gradle panel's `:app:assembleDebug` task, or run in
   Android Studio's terminal (with JDK 17 configured for the terminal):

   Linux/macOS:

   ```bash
   ./gradlew :app:assembleDebug
   ```

   Windows PowerShell:

   ```powershell
   .\gradlew.bat :app:assembleDebug
   ```

9. The resulting automatically debug-signed APK is:

   ```text
   app/build/outputs/apk/debug/app-debug.apk
   ```

Keep the debug build for the `run-as` report-export command below. You do not need
to sign a release APK or publish it to Google Play. An Android emulator can test
the UI but does not contain your Samsung eUICC.

## Install on the S23 FE

1. On the phone, go to **Settings → About phone → Software information** and tap
   **Build number** seven times. Enter your device PIN when asked.
2. Open **Settings → Developer options** and enable **USB debugging**.
3. Connect the phone with a data-capable USB cable. Unlock it and accept the RSA
   debugging authorization prompt.
4. Open a terminal with SDK Platform-Tools on PATH, then run:

   ```bash
   adb devices
   ```

   Your phone should appear as `device`. If it says `unauthorized`, accept the
   authorization prompt. On Windows, install Samsung's official USB driver if
   needed. Samsung installation-security settings can also block sideloading;
   resolve an explicitly reported installation block in the phone's settings.
5. From the project directory:

   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   adb shell am start -n org.example.euiccciprobe/.MainActivity
   ```

   Alternatively, choose your connected phone in Android Studio and press Run.
   Android Studio builds and installs the same application.

## Use it and retrieve the report

1. Leave the phone's existing eSIM configuration in its normal state. Do not
   disable/delete a profile to run this probe. Close any ongoing eSIM download UI.
2. Open **eUICC CI Probe** and wait for the readers to appear. Tap **Refresh readers**
   if necessary.
3. Select a SIM reader and tap **Read CI identifiers**. If multiple SIM readers are
   listed, test each separately; do not assume the numeric reader label is the
   eSIM slot. Only the selected reader is queried.
4. A successful decoded response contains the following labels:

   ```text
   CI_IDENTIFIERS_READ
   euiccCiPKIdListForVerification:
     1. <hexadecimal Subject Key Identifier>
   euiccCiPKIdListForSigning:
     1. <hexadecimal Subject Key Identifier>
   ```

   This is an illustrative format, not observed S23 FE output.
5. Use **Copy report** or **Share report**, or retrieve the latest completed report
   over USB using the debug APK:

   ```bash
   adb exec-out run-as org.example.euiccciprobe cat files/report.txt > euicc-report.txt
   ```

   In older Windows PowerShell versions, use Command Prompt for this redirection
   if you need the original UTF-8 bytes. `run-as` reads the app's own file; it does
   not confer any permission to access the eUICC.
6. Optional live logs:

   ```bash
   adb logcat -s EuiccCiProbe:I
   ```

## Interpreting failure

| Result | Meaning / next step |
|---|---|
| `OMAPI_NOT_CONNECTED` | The service has not connected or is unavailable to this app. Refresh once after waiting. |
| `NO_UICC_READER` | No SIM reader is exposed through OMAPI to this app. Seeing only `eSE*` does not expose the eUICC. |
| `NO_SECURE_ELEMENT` | The selected reader currently has no available card. |
| `ACCESS_DENIED` | The app could not open ISD-R because access was denied by Android/secure-element policy. |
| `APDU_ACCESS_DENIED` | Opening ISD-R succeeded, but an information APDU was filtered. |
| `ISDR_UNAVAILABLE` | The selected reader may be a physical SIM, or ISD-R is unavailable/busy. Test another listed SIM reader; avoid concurrent LPA use. |
| `NO_CHANNEL` | No free logical channel was provided; close any ongoing LPA operation and retry once. |
| `APDU_FAILED` | Inspect the raw SW and response. `6A88` can indicate an unsupported request; `6982`/`6985` can reflect security/state restrictions. |
| `READ_OR_DECODE_FAILED` | Transport or response-format problem; retain the raw response for analysis. |

`ACCESS_DENIED` is not evidence that the eUICC has no CI keys. No runtime permission,
ADB `pm grant`, debug signing, or switch to pySim/lpac can generally fix a missing
privileged/secure-element access authorization.

For your no-root constraint, alternatives are:

- Obtain `euiccInfo1` from your SM-DP+ vendor's `ES9+.InitiateAuthentication` request
  logs during a normal provisioning attempt, subject to the vendor exposing it.
- Obtain an OEM/LPA diagnostic tool or APK explicitly authorized by the relevant
  system/secure-element policy.
- Use a compatible removable eUICC and reader for your RSP lab; this reports that
  card's trust list, not your phone's internal eUICC.

## Identify the CIs after a successful read

Match each hexadecimal SKI against the **Subject Key Identifier** extension of a
published CI certificate. Certificate fingerprints, AKIs, EIDs and APK signer
hashes are different values. Do not use the APK signer hashes as CI identifiers.

The Osmocom inventory is useful:
<https://euicc-manual.osmocom.org/docs/pki/ci/>

For a PEM certificate obtained from its issuer:

```bash
openssl x509 -in ci.pem -noout -subject -issuer -ext subjectKeyIdentifier
```

The reported signing and verification lists may differ; compare them separately.

## Decoder checks and validation limits

With a JDK installed, run:

```bash
bash tools/test_decoder.sh
```

The tests cover synthetic Info1/Info2 responses, ordered multiple keys, long TLV
lengths, unknown fields and rejection of malformed data. They are not hardware or
interoperability tests. During preparation, the pure-Java decoder checks passed;
an Android APK build and installation on a Samsung S23 FE were not performed
because the preparation environment had no Android SDK/Gradle/device.

## Sources

- Attached SGP.22 v2.7: §5.7.2 ES10x transport; §5.7.8 EUICCInfo1/2 and CI lists;
  §2.4.2 ECASD; §2.6.10.1 Common Mutual Authentication.
- Android `Session.openLogicalChannel` and its access-denial behavior:
  <https://developer.android.com/reference/android/se/omapi/Session>
- Android `Channel.transmit`, automatic response handling and APDU filtering:
  <https://developer.android.com/reference/android/se/omapi/Channel>
- Android `SEService` and reader enumeration:
  <https://developer.android.com/reference/android/se/omapi/SEService>
- System/LPA eUICC APIs:
  <https://source.android.com/docs/core/connect/esim-euicc-api>
- Telephony APDU permissions:
  <https://developer.android.com/reference/android/telephony/TelephonyManager>
- AGP 8.9.x compatibility:
  <https://developer.android.com/build/releases/agp-8-9-0-release-notes>

## Remove the diagnostic app

```bash
adb uninstall org.example.euiccciprobe
```
