package org.example.euiccciprobe;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Minimal bounded DER/TLV decoder for SGP.22 EUICCInfo1 and EUICCInfo2. */
public final class EuiccInfoDecoder {
    private EuiccInfoDecoder() {}

    public static final class Info {
        public final String svn;
        public final List<String> verification;
        public final List<String> signing;
        private Info(String svn, List<String> verification, List<String> signing) {
            this.svn = svn;
            this.verification = Collections.unmodifiableList(verification);
            this.signing = Collections.unmodifiableList(signing);
        }
    }

    private static final class Tlv {
        final int tag, start, end;
        Tlv(int tag, int start, int end) {
            this.tag = tag; this.start = start; this.end = end;
        }
    }

    private static final class Cursor {
        final byte[] data;
        final int end;
        int position;
        Cursor(byte[] data, int start, int end) {
            this.data = data; this.position = start; this.end = end;
        }
        int take() {
            if (position >= end) throw new IllegalArgumentException("Truncated TLV");
            return data[position++] & 0xff;
        }
        boolean hasMore() { return position < end; }
        Tlv next() {
            int tag = take();
            if ((tag & 0x1f) == 0x1f) {
                int count = 0, b;
                do {
                    b = take();
                    if (++count > 3) throw new IllegalArgumentException("Tag too long");
                    tag = (tag << 8) | b;
                } while ((b & 0x80) != 0);
            }
            int length = take();
            if ((length & 0x80) != 0) {
                int count = length & 0x7f;
                if (count < 1 || count > 3)
                    throw new IllegalArgumentException("Unsupported/indefinite length");
                length = 0;
                for (int i = 0; i < count; i++) length = (length << 8) | take();
            }
            if (length > end - position) throw new IllegalArgumentException("TLV exceeds buffer");
            Tlv result = new Tlv(tag, position, position + length);
            position += length;
            return result;
        }
    }

    /** Input is the DER payload, WITHOUT the two APDU status bytes. */
    public static Info decode(byte[] payload, int expectedTag) {
        if (payload == null || payload.length > 65536)
            throw new IllegalArgumentException("Invalid payload size");
        Cursor outer = new Cursor(payload, 0, payload.length);
        Tlv root = outer.next();
        if (root.tag != expectedTag || outer.hasMore())
            throw new IllegalArgumentException("Unexpected outer tag or trailing bytes");
        Cursor fields = new Cursor(payload, root.start, root.end);
        String svn = null;
        List<String> verification = null, signing = null;
        while (fields.hasMore()) {
            Tlv field = fields.next();
            if (field.tag == 0x82) {
                if (svn != null || field.end - field.start != 3)
                    throw new IllegalArgumentException("Invalid/duplicate SVN");
                svn = (payload[field.start] & 255) + "."
                    + (payload[field.start + 1] & 255) + "."
                    + (payload[field.start + 2] & 255);
            } else if (field.tag == 0xa9) {
                if (verification != null) throw new IllegalArgumentException("Duplicate verification list");
                verification = readIds(payload, field);
            } else if (field.tag == 0xaa) {
                if (signing != null) throw new IllegalArgumentException("Duplicate signing list");
                signing = readIds(payload, field);
            }
            // Other EUICCInfo2 fields are intentionally skipped by their TLV lengths.
        }
        if (svn == null || verification == null || signing == null)
            throw new IllegalArgumentException("Required SVN/CI list field missing");
        return new Info(svn, verification, signing);
    }

    private static List<String> readIds(byte[] payload, Tlv list) {
        List<String> ids = new ArrayList<>();
        Cursor entries = new Cursor(payload, list.start, list.end);
        while (entries.hasMore()) {
            Tlv entry = entries.next();
            if (entry.tag != 0x04 || entry.start == entry.end)
                throw new IllegalArgumentException("CI identifier is not a non-empty OCTET STRING");
            ids.add(hex(Arrays.copyOfRange(payload, entry.start, entry.end)));
        }
        return ids;
    }

    public static String hex(byte[] bytes) {
        if (bytes == null) return "(null)";
        char[] digits = "0123456789ABCDEF".toCharArray();
        char[] result = new char[bytes.length * 2];
        for (int i = 0; i < bytes.length; i++) {
            result[2 * i] = digits[(bytes[i] & 255) >>> 4];
            result[2 * i + 1] = digits[bytes[i] & 15];
        }
        return new String(result);
    }

    public static byte[] unhex(String text) {
        String value = text.replaceAll("\\s+", "");
        if ((value.length() & 1) != 0) throw new IllegalArgumentException("Odd hex length");
        byte[] bytes = new byte[value.length() / 2];
        for (int i = 0; i < bytes.length; i++) {
            int hi = Character.digit(value.charAt(2 * i), 16);
            int lo = Character.digit(value.charAt(2 * i + 1), 16);
            if (hi < 0 || lo < 0) throw new IllegalArgumentException("Invalid hex");
            bytes[i] = (byte) ((hi << 4) | lo);
        }
        return bytes;
    }
}
