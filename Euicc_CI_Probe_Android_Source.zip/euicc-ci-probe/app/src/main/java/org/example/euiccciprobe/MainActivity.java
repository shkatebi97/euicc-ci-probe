package org.example.euiccciprobe;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.se.omapi.Channel;
import android.se.omapi.Reader;
import android.se.omapi.SEService;
import android.se.omapi.Session;
import android.telephony.euicc.EuiccInfo;
import android.telephony.euicc.EuiccManager;
import android.util.Log;
import android.view.WindowInsets;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Ordinary, unprivileged APK: probes only access allowed by Android/SE policy. */
public final class MainActivity extends Activity {
    private static final String LOG_TAG = "EuiccCiProbe";
    private static final byte[] ISDR_AID =
        EuiccInfoDecoder.unhex("A0000005591010FFFFFFFF8900000100");
    private static final byte[] INFO1_APDU = EuiccInfoDecoder.unhex("80E2910003BF200000");
    private static final byte[] INFO2_APDU = EuiccInfoDecoder.unhex("80E2910003BF220000");
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private SEService service;
    private volatile boolean destroyed;
    private boolean busy;
    private List<Reader> uiccReaders = new ArrayList<>();
    private Spinner readerPicker;
    private Button refreshButton, readButton;
    private TextView output;
    private String lastReport = "Starting OMAPI connection...";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        createUi();
        publish(lastReport);
        try {
            service = new SEService(this, worker,
                () -> main.post(() -> { if (!destroyed) refreshReaders(); }));
        } catch (Exception e) {
            publish("OMAPI_INITIALIZATION_FAILED\n" + detail(e));
        }
        main.postDelayed(() -> {
            if (!destroyed && service != null && !service.isConnected() && !busy) {
                publish("OMAPI_NOT_CONNECTED\nThe firmware may not provide an accessible "
                    + "SecureElementService. Tap Refresh readers to check again.");
            }
        }, 10000);
    }

    private void createUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int padding = dp(16);
        root.setPadding(padding, padding, padding, padding);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars()
                    | WindowInsets.Type.displayCutout());
                view.setPadding(padding + bars.left, padding + bars.top,
                    padding + bars.right, padding + bars.bottom);
            } else {
                view.setPadding(padding + insets.getSystemWindowInsetLeft(),
                    padding + insets.getSystemWindowInsetTop(),
                    padding + insets.getSystemWindowInsetRight(),
                    padding + insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        TextView title = new TextView(this);
        title.setText("eUICC CI Probe"); title.setTextSize(23);
        root.addView(title);
        TextView explanation = new TextView(this);
        explanation.setText("Tests ordinary-app access. Your phone may deny access to its "
            + "internal eUICC. Select a SIM reader; SIM1/SIM2 labels depend on firmware.");
        root.addView(explanation);
        readerPicker = new Spinner(this); root.addView(readerPicker);
        refreshButton = button(root, "Refresh readers", this::refreshReaders);
        readButton = button(root, "Read CI identifiers", this::readSelected);
        readButton.setEnabled(false);
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        button(actions, "Copy report", () -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("eUICC diagnostic report", lastReport));
            Toast.makeText(this, "Report copied", Toast.LENGTH_SHORT).show();
        });
        button(actions, "Share report", () -> {
            Intent share = new Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, lastReport);
            startActivity(Intent.createChooser(share, "Share diagnostic report"));
        });
        root.addView(actions);
        ScrollView scroll = new ScrollView(this);
        output = new TextView(this);
        output.setTypeface(Typeface.MONOSPACE); output.setTextSize(12);
        output.setTextIsSelectable(true); scroll.addView(output);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        root.requestApplyInsets();
    }

    private Button button(LinearLayout parent, String label, Runnable action) {
        Button button = new Button(this); button.setText(label);
        button.setOnClickListener(v -> action.run()); parent.addView(button);
        return button;
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void refreshReaders() {
        if (busy) return;
        if (service == null || !service.isConnected()) {
            publish("OMAPI_NOT_CONNECTED\nWait a few seconds, then tap Refresh readers.");
            return;
        }
        setBusy(true);
        worker.execute(() -> {
            List<Reader> available = new ArrayList<>();
            StringBuilder report = baseline();
            try {
                report.append("OMAPI version: ").append(service.getVersion()).append('\n');
                Reader[] readers = service.getReaders();
                report.append("Readers returned: ").append(readers.length).append('\n');
                for (Reader reader : readers) {
                    String name = reader.getName();
                    report.append("Reader: ").append(name).append('\n');
                    if (name.toUpperCase(Locale.ROOT).startsWith("SIM")) available.add(reader);
                }
                report.append(available.isEmpty()
                    ? "\nNO_UICC_READER: internal eUICC is not exposed as a SIM reader to this app.\n"
                    : "\nSelect each relevant SIM reader and tap Read CI identifiers.\n");
                report.append("Reader names alone do not identify a physical SIM versus an eUICC.\n");
            } catch (Exception e) {
                report.append("READER_ENUMERATION_FAILED\n").append(detail(e));
            }
            String text = report.toString();
            main.post(() -> {
                if (destroyed) return;
                uiccReaders = available;
                List<String> labels = new ArrayList<>();
                for (Reader reader : available) labels.add(reader.getName());
                if (labels.isEmpty()) labels.add("No SIM reader available");
                ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, labels);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                readerPicker.setAdapter(adapter);
                publish(text); setBusy(false);
            });
        });
    }

    private void readSelected() {
        if (busy || uiccReaders.isEmpty()) return;
        int index = readerPicker.getSelectedItemPosition();
        if (index < 0 || index >= uiccReaders.size()) return;
        Reader reader = uiccReaders.get(index);
        setBusy(true); output.setText("Reading " + reader.getName() + "...");
        worker.execute(() -> {
            StringBuilder report = baseline();
            report.append("Selected reader: ").append(reader.getName()).append('\n');
            Session session = null;
            Channel channel = null;
            try {
                if (!reader.isSecureElementPresent()) {
                    report.append("NO_SECURE_ELEMENT: selected reader has no available card.\n");
                } else {
                    session = reader.openSession();
                    report.append("ATR: ").append(EuiccInfoDecoder.hex(session.getATR())).append('\n');
                    report.append("Selecting ISD-R: ").append(EuiccInfoDecoder.hex(ISDR_AID)).append('\n');
                    channel = session.openLogicalChannel(ISDR_AID, (byte) 0x00);
                    if (channel == null) {
                        report.append("NO_CHANNEL: no logical channel is available.\n");
                    } else {
                        report.append("SELECT response: ")
                            .append(EuiccInfoDecoder.hex(channel.getSelectResponse())).append('\n');
                        boolean one = query(channel, "EUICCInfo1", INFO1_APDU, 0xbf20, report);
                        boolean two = query(channel, "EUICCInfo2", INFO2_APDU, 0xbf22, report);
                        report.append(one || two
                            ? "\nCI_IDENTIFIERS_READ: at least one CI-list response decoded.\n"
                            : "\nCI_IDENTIFIERS_NOT_READ: inspect the errors above.\n");
                    }
                }
            } catch (SecurityException e) {
                report.append("ACCESS_DENIED\n").append(detail(e))
                    .append("\nAndroid/secure-element policy denied ISD-R access to this APK. "
                        + "A normal runtime permission or USB debugging cannot override that policy.\n");
            } catch (NoSuchElementException e) {
                report.append("ISDR_UNAVAILABLE\n").append(detail(e))
                    .append("\nPossible causes: physical SIM, different reader, unavailable ISD-R, "
                        + "or another app holding a non-multiselectable ISD-R.\n");
            } catch (Exception e) {
                report.append("PROBE_FAILED\n").append(detail(e)).append('\n');
            } finally {
                if (channel != null) try { channel.close(); } catch (Exception e) {
                    report.append("Channel close: ").append(detail(e)).append('\n');
                }
                if (session != null) try { session.close(); } catch (Exception e) {
                    report.append("Session close: ").append(detail(e)).append('\n');
                }
            }
            String text = report.toString();
            main.post(() -> { if (!destroyed) { publish(text); setBusy(false); } });
        });
    }

    private boolean query(Channel channel, String label, byte[] command, int tag,
                          StringBuilder report) {
        report.append('\n').append(label).append(" request: ")
            .append(EuiccInfoDecoder.hex(command)).append('\n');
        try {
            // OMAPI sets the logical-channel bits and handles 61xx/6Cxx internally.
            byte[] response = channel.transmit(command.clone());
            report.append(label).append(" raw response: ")
                .append(EuiccInfoDecoder.hex(response)).append('\n');
            if (response == null || response.length < 2)
                throw new IllegalArgumentException("Missing APDU status words");
            int sw1 = response[response.length - 2] & 255;
            int sw = (sw1 << 8) | (response[response.length - 1] & 255);
            report.append("SW: ").append(String.format(Locale.ROOT, "%04X", sw)).append('\n');
            if (sw != 0x9000 && sw1 != 0x91) {
                report.append("APDU_FAILED: CI information was not decoded.\n"); return false;
            }
            if (sw1 == 0x91) report.append("Proactive command pending; this app does not FETCH it.\n");
            EuiccInfoDecoder.Info info = EuiccInfoDecoder.decode(
                Arrays.copyOf(response, response.length - 2), tag);
            report.append("SGP.22 SVN: ").append(info.svn).append('\n');
            list(report, "euiccCiPKIdListForVerification", info.verification);
            list(report, "euiccCiPKIdListForSigning", info.signing);
            return true;
        } catch (SecurityException e) {
            report.append("APDU_ACCESS_DENIED: ").append(detail(e)).append('\n');
        } catch (Exception e) {
            report.append("READ_OR_DECODE_FAILED: ").append(detail(e)).append('\n');
        }
        return false;
    }

    private void list(StringBuilder report, String name, List<String> ids) {
        report.append(name).append(":\n");
        if (ids.isEmpty()) report.append("  (empty list)\n");
        for (int i = 0; i < ids.size(); i++)
            report.append("  ").append(i + 1).append(". ").append(ids.get(i)).append('\n');
    }

    private StringBuilder baseline() {
        StringBuilder report = new StringBuilder("eUICC CI Probe 1.0\n");
        report.append("Model: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n');
        report.append("Android: ").append(Build.VERSION.RELEASE).append(" / API ")
            .append(Build.VERSION.SDK_INT).append('\n');
        report.append("Package: ").append(getPackageName()).append('\n');
        PackageManager pm = getPackageManager();
        report.append("OMAPI UICC feature: ")
            .append(pm.hasSystemFeature("android.hardware.se.omapi.uicc")).append('\n');
        report.append("eUICC feature: ")
            .append(pm.hasSystemFeature("android.hardware.telephony.euicc")).append('\n');
        try {
            EuiccManager manager = (EuiccManager) getSystemService(EUICC_SERVICE);
            report.append("Public EuiccManager enabled: ")
                .append(manager != null && manager.isEnabled()).append('\n');
            if (manager != null && manager.isEnabled()) {
                EuiccInfo info = manager.getEuiccInfo();
                report.append("Public eUICC OS version (not CI lists): ")
                    .append(info == null ? "unavailable" : info.getOsVersion()).append('\n');
            }
        } catch (Exception e) {
            report.append("Public eUICC metadata: ").append(detail(e)).append('\n');
        }
        try {
            PackageInfo info = pm.getPackageInfo(getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
            Signature[] signatures = info.signingInfo.getApkContentsSigners();
            for (Signature signature : signatures) {
                byte[] certificate = signature.toByteArray();
                report.append("APK signer SHA-1: ").append(EuiccInfoDecoder.hex(
                    MessageDigest.getInstance("SHA-1").digest(certificate))).append('\n');
                report.append("APK signer SHA-256: ").append(EuiccInfoDecoder.hex(
                    MessageDigest.getInstance("SHA-256").digest(certificate))).append('\n');
            }
        } catch (Exception e) { report.append("Signer: ").append(detail(e)).append('\n'); }
        report.append("CI values below are SKIs, not full certificates.\n");
        return report;
    }

    private String detail(Exception e) {
        return e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage());
    }
    private void setBusy(boolean value) {
        busy = value; refreshButton.setEnabled(!value);
        readerPicker.setEnabled(!value && !uiccReaders.isEmpty());
        readButton.setEnabled(!value && !uiccReaders.isEmpty());
    }
    private void publish(String text) {
        lastReport = text;
        output.setText(text);
        // Persist failures as well as successful probes, using the same worker queue.
        worker.execute(() -> saveAndLog(text));
    }
    private void saveAndLog(String report) {
        try (FileOutputStream stream = new FileOutputStream(new File(getFilesDir(), "report.txt"))) {
            stream.write(report.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) { Log.e(LOG_TAG, "Cannot save report", e); }
        for (String line : report.split("\n")) {
            for (int offset = 0; offset < line.length(); offset += 3000)
                Log.i(LOG_TAG, line.substring(offset, Math.min(offset + 3000, line.length())));
        }
    }
    @Override public void onDestroy() {
        destroyed = true;
        main.removeCallbacksAndMessages(null);
        worker.execute(() -> { if (service != null) service.shutdown(); });
        worker.shutdown();
        super.onDestroy();
    }
}
